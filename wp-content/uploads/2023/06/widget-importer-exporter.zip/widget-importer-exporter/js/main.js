jQuery(document).ready(function ($) {

    // Show textarea when click "copy and paste"
    $('#wie-content-toggle').on('click', function () {
        $('#wie-import-data').fadeIn('fast').focus();
    });

});
